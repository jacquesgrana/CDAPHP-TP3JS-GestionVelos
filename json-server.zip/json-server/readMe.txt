déplacer le zip dans le dossier qui est un niveau au dessus de la racine du projet.

dézipper

ouvrir un terminal dans le nouveau dossier 'json-server' obtenu en dézippant

et taper : json-server db.json
